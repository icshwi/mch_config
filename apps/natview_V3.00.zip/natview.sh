#!/bin/bash
###############################################################################
# NAME
#	natview (NOTE: Script name needs to be changed to fit the name of
#       the Java archive it needs to call!!! See below for details!!!)
#
# DESCRIPTION
#	Java application starter script.
#
#	This script is neccessary to startup a Java application properly. It
#       does the following things:
#
#	1. Change the directory to the one where this script lives. This is
#	   the reason that this script must be copied to the same directory
#	   as the corresponding jar file.
#
#	2. Extract the script name minus its extension and build the java
#	   command line from this.
#
# HISTORY
#	080610 ss Initial version;
###############################################################################

APP_PATH=${0%/*}
APP_NAME_WITH_EXT=${0##*/}
APP_NAME=${APP_NAME_WITH_EXT%.*}

#echo "APP_PATH         =${APP_PATH}"
#echo "APP_NAME_WITH_EXT=${APP_NAME_WITH_EXT}"
#echo "APP_NAME         =${APP_NAME}"

cd ${APP_PATH}
java -jar ${APP_NAME}.jar

#
# EOF
#

